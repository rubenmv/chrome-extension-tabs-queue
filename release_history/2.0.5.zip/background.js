/*global chrome*/
"use strict";
var DEBUG_MODE = false;

var DEFAULT_ID = -1,
    whitelist = [
        // The "suspended.html" part is an exception for "The Great Suspender" suspended tabs
        /^chrome[:|-](?!.*suspended\.html).*/,
        // Pixis redirection to external sites only work when the tab is opened
        // directy from pixiv not from newtab page
        /^https\:\/\/www\.pixiv\.net\/jump\.php.*/
    ],

    // Is extension active?
    isActive = true,
    // When a new tab is queued, it is instantly closed
    // this flag alerts not to open a new tab when this happens (onRemovedTab)
    isQueuing = false,
    isOverriding = false, // Next tab to open will override tab limit 
    storing = false, // To check if currently there"s a store operation waiting to finish
    updater = null, // Saves interval function
    checkingItems = false,
    // Tabs waiting for url update (before queuing)
    tabsWaiting = [],
    tabLimit = 10,
    lifo = false, // last-in-first-out. New items to top of the queue
    allowDuplicates = false,
    slowNetworkMode = false,
    slowNetworkLimit = 0, // Slow network mode (active if > 0)
    queueByRecent = false,
    queues = []; // Array of queued items
// Regular expressions for url exclusions
var ICON_DEFAULT = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAABmJLR0QA/wD/AP+gvaeTAAAAqElEQVR4nO3aQQrCQBBE0Y54/yOrW5GABI0fmfeWs2iKYtLMIjMAAMCKtpm5nzDz2afzT513+XDY31NAHaB23Tl7/ebe+fYO+anlb4AC6gC1vXeAHbASBdQBanvvgKOO7ozSNjO354Plb4AC6gA1BdQBagqoA9QUUAeoKaAOUFNAHaCmgDpATQF1gJoC6gA1BdQBagqoA9TO+Eforyx/AxRQBwAAACg8AEejCFAaFqVwAAAAAElFTkSuQmCC";
var ICON_DISABLED = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAMAAACdt4HsAAABcVBMVEUAAAD/AAD///8AAAD/AAD/AAD/AAD/AAD/AAD/AAD/AAD/AAD/AAD/AAD/AAD/AAD/AAD/AAD/AAD/AAD/AAD/AAD/AAD/AAD/AAD/AAD/AAD/AAD/AAD/AAD/AAD/AAD/AAD/AAD/AAD/AAD/AAD/AAD/AAD/AAD/AAD/AAD/AAD/AAD/AAD/AAD/AAD/AAD/AAD/AAD/AAD/AAD/AAD/AAD/AAD/AAD/AAD/AAD/AAD/AAD/AAD/AAD/AAD/AAD/AAD/AAD/AAD/AAD/AAD/AAD/AAD/AAD/AAD/AAD/AAD/AAD/AAD/AAD/AAD/AAD/AAAAAAABAAADAAAGAAAKAAAPAAAVAAAcAAAiAAAjAAApAAAtAAA3AABCAABHAABQAABZAABjAABpAAB4AAB6AACHAACQAACbAACkAACxAAC9AAC/AADCAADIAADPAADXAADbAADjAADqAADuAADxAAD1AAD5AAD8AAD+AAD/AAB4L4E0AAAAUXRSTlMAAAABAQMFBgcJCgsMDQ8VFhweICUnKi0uNDY3QkNGTlJUVVhgYmVnaXh5iIuMj52foKGio66wsba5vb7CyMnKzM7W2drb4+bq6/Dz9ff5/P5esCL3AAABx0lEQVR42u3XR1MCQRCGYXoFs6yKGRRzzjlnESOOOeecxTy/Xl3Lni1Bl25ult9xtt7n1oe1aVHuHwgDgMVKm2OjArwB2ZkUBeCZkVL262wgd1J+bMTFBDL88nPjOSwgzSe/1ssB9GHsx1IVIMIM3hfyltKHfXBdGLO9L2Igrhv7h01BBxbasH/aEnRg/hT75x0RAthMCw8cY/+yJxjAocQdCAaw/4r9kWAAuy/YnwhrIGTbz9ifzYd8tQa2HrE/XxB0YOMe+8slQQdWg9jfLItIgG8HNKoOSDdebGox1oBzAHufC+hAvDqgiWygA44O7KfdQAfsjdjP5gMDqMU+UAwMoAr7uUpgABVzCFQBAygKYF8HDMAzi32TnQG4p7HvcAAdyPZj350AdCDdh/2gE+iAPmY+IDrgHFIHlAZ0ILEHe38W0AHTAU25gQ7YW9UBeYAB1KsDKgQGUK0OqBwYQKU0HRADKFEHVAMMoEAdUIOdAZgOqN0BJMDY5gP2F4si4iGwFsT+elnQgZU77G9XBAO4wj64KmiAZixn/OuAMuH3/fS/4Box+sk8YAKaPmAckMYGtOQuGfBqDAAX11KmWQP//41/EngDrVcKealcgDwAAAAASUVORK5CYII=";

function clog(text) {
    if (DEBUG_MODE == true)
        console.log(text);
}

function cerror(text) {
    if (DEBUG_MODE == true)
        console.error(text);
}

/*********************************************
 * CLASSES
 */
/**
 * Queue
 */
function Queue(windowId) {
    this.window = windowId,
        this.name = formatDateTime(Date.now()),
        this.items = [],
        this.openingTab = false; // Currently opening a tab
}
/**
 * Item. Contains info about the tab saved in queue.
 */
function Item(id, windowId, url, title, state, locked) {
    this.id = id,
        this.window = windowId, // original window/queue where it was created
        this.url = url,
        this.title,
        this.state = state,
        this.locked = locked;
}
/**
 * Changes the lock state an item in the current/active queue
 */
function setLock(queueId, index, value) {
    var currentQueue = getQueue(queueId).items;
    if (currentQueue.length > 0) {
        currentQueue[index].locked = value;
        cleanAndStore();
    }
}
/*********************************************
 * QUEUE AND ITEM METHODS
 */
/**
 * Extend Array object to include move method
 */
Array.prototype.move = function(oldIndex, newIndex) {
    while (oldIndex < 0) {
        oldIndex += this.length;
    }
    while (newIndex < 0) {
        newIndex += this.length;
    }
    if (newIndex >= this.length) {
        var k = newIndex - this.length;
        while ((k--) + 1) {
            this.push(undefined);
        }
    }
    this.splice(newIndex, 0, this.splice(oldIndex, 1)[0]);
    return this; // for testing purposes
};
/**
 * Moves item position from specific queue
 */
function moveItemInQueue(queueId, oldPos, newPos) {
    var queue = getQueue(queueId).items;
    queue.move(oldPos, newPos);
    cleanAndStore();
}
/**
 * Returns the queue of a window. Creates one if it doesn"t exists.
 */
function getQueue(windowId) {
    for (var i = 0; i < queues.length; i++) {
        if (queues[i].window !== DEFAULT_ID && queues[i].window == windowId) {
            return queues[i];
        }
    }
    // Not found: creates new queue
    var newQueue = new Queue(windowId);
    queues.push(newQueue);
    return newQueue;
}
/**
 * Check if tab is on the wait list (new) and remove it
 */
function findTabWaiting(tabId, remove) {
    for (var i = 0; i < tabsWaiting.length; i++) {
        if (tabId === tabsWaiting[i].id) {
            if (remove) {
                tabsWaiting.splice(i, 1);
            }
            return true;
        }
    }
    return false;
}
/**
 * Check if url is in queue. Returns index, -1 if not found
 */
function findInQueue(qu, url) {
    //var currentQueue = getQueue(queue).items;
    for (var i = 0; i < qu.length; i++) {
        if (qu[i].url === url) {
            return i;
        }
    }
    return -1;
}
/**
 * Check if the url matches something in whitelist
 */
function isInWhitelist(url) {
    for (var i = 0; i < whitelist.length; i++) {
        if (whitelist[i].test(url)) {
            return true;
        }
    }
    return false;
}
/**
 * Delete queue
 */
function removeQueue(index) {
    queues.splice(index, 1);
    cleanAndStore();
}
/**
 * Removes all queues
 */
function clearQueues() {
    queues = [];
    cleanAndStore();
}
/**
 * Removes only saved queues
 */
function clearSavedQueues() {
    var i = 0;
    while (i < queues.length) {
        if (queues[i].window === DEFAULT_ID) {
            queues.splice(i, 1);
        } else {
            i++;
        }
    }
    cleanAndStore();
}
/**
 * Removes all items in queue
 */
function clearItems(queueId) {
    var currentQueue = getQueue(queueId);
    currentQueue.items = [];
    cleanAndStore();
}
/**
 * Close tab and add it to queue
 */
function queueTab(tabState) {
    if (!isInWhitelist(tabState.url)) {
        clog("Queue tab: " + tabState.title);
        // Create item
        var item = new Item(tabState.id, tabState.windowId, tabState.url, tabState.title, tabState.status, false);
        // Save to queue and local storage
        saveItem(item);
        isQueuing = true;
        chrome.tabs.remove(tabState.id, function() {
            if (chrome.runtime.lastError !== undefined) {
                cerror(`An error ocurred in ${queueTab.name}: ${chrome.runtime.lastError.string}`);
            }
        });
    }
}
/**
 * Compare function to sort tabs array
 */
function compareById(a, b) {
    if (a.id < b.id) return -1;
    if (a.id > b.id) return 1;
    return 0;
}
/**
 * Queue tabs on the right to fit limit
 */
function queueToLimit(windowId) {
    chrome.tabs.query({
        "windowId": windowId,
        "pinned": false
    }, function(tabs) {
        if (chrome.runtime.lastError !== undefined) {
            cerror(`An error ocurred in ${queueToLimit.name}: ${chrome.runtime.lastError.string}`);
        }

        // Discard tabs from whitelist
        for (var i = 0; i < tabs.length; i++) {
            if (isInWhitelist(tabs[i].url)) {
                tabs.splice(i, 1);
                i--;
            }
        }
        if (tabs.length > tabLimit) {
            if (queueByRecent) {
                tabs = tabs.sort(compareById);
            }
            for (var i = tabLimit; i < tabs.length; i++) {
                queueTab(tabs[i]);
            }
        }
    });
}
/**
 * Push new url to queue and save it in local storage
 */
function saveItem(item) {
    var qu = getQueue(item.window).items;
    if (!allowDuplicates) {
        // If duplicate, don"t push and move it to top
        var p = findInQueue(qu, item.url);
        if (p >= 0) {
            qu.move(p, 0); // Move to top
            return;
        }
    }
    // Push to queue
    if (lifo) {
        qu.unshift(item);
    } else {
        qu.push(item);
    }
    // Update local storage and badge
    cleanAndStore();
    updateBadgeCounter();
}
/**
 * Removes item from queue and storage
 */
function removeItem(queueId, index) {
    clog("removeItem. queueId: " + queueId + ", index: " + index);
    try {
        var itemQueue = getQueue(queueId).items;
        // Remove from queue
        itemQueue.splice(index, 1);
        cleanAndStore();
    } catch (error) {
        cerror("Error al eliminar item de la lista. queueId: " + queueId + ", index: " + index);
    }

}
/***********************************************************
 * GENERAL
 */
/**
 * Gets date and returns formatted human readable date/time as string
 * Input and output must be strings
 */
function formatDateTime(dt) {
    var datetime = new Date(dt);
    try {
        // magic!! slice(-2) starts counting from the end, so it leaves only the last two digits. Ex: Month = 9 -> 09 -> 09 :: Month = 11 -> 011 -> 11
        dt = datetime.getFullYear() + '-' + ('0' + (datetime.getMonth() + 1)).slice(-2) + "-" + ('0' + datetime.getDate()).slice(-2) + " " + ('0' + datetime.getHours()).slice(-2) + ":" + ('0' + datetime.getMinutes()).slice(-2) + ":" + ('0' + datetime.getSeconds()).slice(-2);
    } catch (err) {
        dt = "queue";
        cerror(err);
    }
    return dt;
}
/**
 * Change active state and browser action icon
 */
function setActive(active) {
    isActive = active;
    // Save to storage
    chrome.storage.local.set({
        "isActive": isActive
    });
    // Change icon
    var icon = isActive ? ICON_DEFAULT : ICON_DISABLED;
    // Active/deactive update interval
    if (isActive) {
        setUpdater();
    } else {
        window.clearInterval(updater);
    }
    chrome.browserAction.setIcon({
        path: icon
    });
}
/**
 * Updates counter in browser action icon/button
 */
function updateBadgeCounter() {
    chrome.tabs.query({
        currentWindow: true,
        active: true
    }, function(tabs) {
        if (chrome.runtime.lastError !== undefined) {
            cerror(`An error ocurred in ${updateBadgeCounter.name}: ${chrome.runtime.lastError.string}`);
            return;
        }

        var currentTab = tabs[0];
        // Other window types like popup or app
        if (!currentTab) {
            return;
        }
        var badgeColor = "#00ff00";
        var currentQueue = getQueue(currentTab.windowId).items;
        if (currentQueue.length > 0) {
            badgeColor = "#ff0000";
        }
        chrome.browserAction.setBadgeBackgroundColor({
            "color": badgeColor,
        });
        chrome.browserAction.setBadgeText({
            "text": currentQueue.length.toString(),
            "tabId": currentTab.id
        });
    });
}
/**
 * Initialize settings and load queues
 */
function init() {
    //sync.get callback, data received
    function optionsDataRetrieved(data) {
        // Check for error
        if (chrome.runtime.lastError !== undefined) {
            cerror("An error ocurred initializing options: " + chrome.runtime.lastError.string);
            return;
        }
        // Initialize properties
        if (data.hasOwnProperty("tabLimit")) {
            tabLimit = data.tabLimit;
        }
        if (data.hasOwnProperty("lifo")) {
            lifo = data.lifo;
        }
        if (data.hasOwnProperty("allowDuplicates")) {
            allowDuplicates = data.allowDuplicates;
        }
        if (data.hasOwnProperty("queueByRecent")) {
            queueByRecent = data.queueByRecent;
        }
        if (data.hasOwnProperty("slowNetworkMode")) {
            slowNetworkMode = data.slowNetworkMode;
        }
        if (data.hasOwnProperty("slowNetworkLimit")) {
            slowNetworkLimit = data.slowNetworkLimit;
        }
        if (data.hasOwnProperty("isActive")) {
            isActive = data.isActive;
        }
        var iconPath = isActive ? ICON_DEFAULT : ICON_DISABLED;
        chrome.browserAction.setIcon({
            "path": iconPath
        });
        if (data.hasOwnProperty("queues")) {
            queues = JSON.parse(data.queues);
        }
        initQueues();
        setUpdater();
        // Restore queues on start?
        if (isActive && data.hasOwnProperty("restoreOnStart") && data.restoreOnStart) {
            restoreSavedQueues();
        }
        // Context menu
        if (data.hasOwnProperty("hideContextMenu") && !data.hideContextMenu) {
            createContextMenu();
        }
    }
    // Get the options from sync storage
    chrome.storage.local.get(null, optionsDataRetrieved);
}
/**
 * Resets queues ids
 */
function initQueues() {
    if (queues.length === 0) {
        return;
    }
    // First cleanup all reference to window ids to prevent mixup
    for (var i = 0; i < queues.length; i++) {
        var q = queues[i];
        q.window = DEFAULT_ID;
        for (var j = 0; j < q.items.length; j++) {
            q.items[j].window = DEFAULT_ID;
        }
    }
}
/**
 * Check tabs every x seconds and update badge counter
 */
function setUpdater() {
    updater = window.setInterval(function() {
        if (!isActive) {
            return;
        }
        // Get all windows info
        chrome.windows.getAll({
            "populate": true
        }, function(windows) {
            for (var i = 0; i < windows.length; i++) {
                if (windows[i].type === "normal" && !checkingItems) {
                    checkingItems = true;
                    checkOpenNextItems(windows[i]);
                    checkingItems = false;
                }
            }
        });
        updateBadgeCounter();
    }, 500);
}
/**
 * Calculate free space based on active limits given a set of tabs
 * Return number of free spaces
 */
function calculateFreespace(tabs) {
    var tabCount = 0,
        loadingTabCount = 0;
    for (var i = 0; i < tabs.length; i++) {
        if (!isInWhitelist(tabs[i].url) && !tabs[i].pinned) {
            tabCount++;
            if (tabs[i].status === "loading") {
                loadingTabCount++;
            }
        }
    }

    var freeSpace = tabLimit - tabCount;
    if (freeSpace > 0) {
        if (slowNetworkMode) { // Slow network mode active
            var loadingSpace = slowNetworkLimit - loadingTabCount;
            if (loadingSpace < freeSpace) {
                freeSpace = loadingSpace;
            }
        }
    }
    return freeSpace;
}
/**
 * Try to open next item in queue
 * Works in conjunction with a timeout to trigger a new check
 */
function checkOpenNextItems(wdw) {
    // Check how many tabs can we create
    // Windows like popups and other will also trigger
    // if there are no tabs just cancel
    if (wdw.tabs.length == 0) {
        return;
    }
    var currentQueue = getQueue(wdw.id).items;
    var freeSpace = calculateFreespace(wdw.tabs);
    // Free space and items waiting
    if (freeSpace > 0 && currentQueue.length > 0) {
        // Create as many tabs as possible
        // First create the tabs, then remove the items from queue
        // after ALL new tabs have been created
        var j = 0;
        clog("freeSpace: " + freeSpace);
        while (freeSpace > 0 && j < currentQueue.length) {
            if (!currentQueue[j].locked) {
                clog("create: " + currentQueue[j].url);
                chrome.tabs.create({
                    "windowId": wdw.id,
                    "url": currentQueue[j].url,
                    "active": false
                }, function() {
                    if (chrome.runtime.lastError !== undefined) {
                        cerror(`An error ocurred in ${updateBadgeCounter.name}: ${chrome.runtime.lastError.string}`);
                        return;
                    }
                });
                removeItem(wdw.id, j);
                freeSpace--;
            } else {
                j++;
            }
        }
    }
}
/**
 * Opens a new tab with an url.
 * override = the tab goes into the override limit list
 * replaceCurrent = instead of new tab, replace/load in current
 */
function openUrlInTab(windowId, url, position, override, replaceCurrent) {
    isOverriding = override;
    // If loads in current, no need to override limit
    if (replaceCurrent) {
        chrome.tabs.update({
            "url": url
        }, function() {
            if (chrome.runtime.lastError !== undefined) {
                cerror(`An error ocurred in ${openUrlInTab.name}: ${chrome.runtime.lastError.string}`);
            }
        });
    }
    // Create new tab
    else {
        if (position > -1) {
            chrome.tabs.create({
                "windowId": windowId,
                "url": url,
                "index": position,
                "active": false
            }, function() {
                if (chrome.runtime.lastError !== undefined) {
                    cerror(`An error ocurred in ${openUrlInTab.name}: ${chrome.runtime.lastError.string}`);
                }
            });
        } else {
            chrome.tabs.create({
                "windowId": windowId,
                "url": url,
                "active": false
            }, function() {
                if (chrome.runtime.lastError !== undefined) {
                    cerror(`An error ocurred in ${openUrlInTab.name}: ${chrome.runtime.lastError.string}`);
                }
            });
        }
    }
}
/**
 * Open new window with associated queue
 */
function openQueueInWindow(queue) {
    chrome.windows.create({
        "focused": false
    }, function(windowInfo) {
        // Update queue and items with the new window id
        queue.window = windowInfo.id;
        var items = queue.items;
        for (var j = 0; j < items.length; j++) {
            items[j].window = windowInfo.id;
        }
    });
}
/**
 * Restores a queue given an index in the list
 */
function restoreQueue(index) {
    if (queues.length <= index) {
        return;
    }
    openQueueInWindow(queues[index]);
}
/**
 * Open all saved queues into new windows
 */
function restoreSavedQueues() {
    for (var i = 0; i < queues.length; i++) {
        if (queues[i].window === DEFAULT_ID) {
            openQueueInWindow(queues[i]);
        }
    }
}
/**
 * Merges queue with current and removes it
 * index = position of queue to merge
 * currentId = id of current window queue
 */
function mergeQueue(index, currentId) {
    if (queues.length <= index) {
        return;
    }
    var current = getQueue(currentId),
        qMerger = queues[index];
    for (var i = 0; i < qMerger.items.length; i++) {
        current.items.push(qMerger.items[i]);
    }
    queues.splice(index, 1);
}
/**********************************************
 * STORAGE
 */
/**
 * Settings changes
 */
function onSettingsChanged(changes, namespace) {
    var key, storageChange, newValue;
    for (key in changes) {
        if (changes.hasOwnProperty(key)) {
            storageChange = changes[key];
            newValue = storageChange.newValue;
            if (key === "tabLimit") {
                tabLimit = newValue;
            } else if (key === "lifo") {
                lifo = newValue;
            } else if (key === "allowDuplicates") {
                allowDuplicates = newValue;
            } else if (key === "queueByRecent") {
                queueByRecent = newValue;
            } else if (key === "hideContextMenu") {
                if (newValue) {
                    chrome.contextMenus.removeAll();
                } else {
                    createContextMenu();
                }
            } else if (key === "slowNetworkMode") {
                slowNetworkMode = newValue;
            } else if (key === "slowNetworkLimit") {
                slowNetworkLimit = newValue;
            }
        }
    }
}
/**
 * Remove empty queues and save in local storage
 */
function cleanAndStore() {
    if (!storing) {
        storing = true;
        var timer = window.setTimeout(function() {
            // cleanup
            var i = 0;
            while (i < queues.length) {
                // Remove empty queues
                if (queues[i].items.length === 0) {
                    queues.splice(i, 1);
                } else {
                    i++;
                }
            }
            // storage works only with strings
            var jsonQueues = JSON.stringify(queues);
            chrome.storage.local.set({
                "queues": jsonQueues
            }, function() {
                if (chrome.runtime.lastError !== undefined) {
                    cerror("An error ocurred saving queues: " + chrome.runtime.lastError.string);
                }
            });
            window.clearTimeout(timer);
            storing = false;
        }, 2000);
    }
}
/********************************************
 * CONTEXT MENU
 */
function createContextMenu() {
    chrome.contextMenus.create({
        "id": "context_no_queue",
        "title": "Open link in new tab (don't queue)",
        "contexts": ["link"],
        "onclick": onContextMenuLinkClicked
    });
    chrome.contextMenus.create({
        "id": "context_queue",
        "title": "Send link to queue",
        "contexts": ["link"],
        "onclick": onContextMenuLinkClicked
    });
    chrome.contextMenus.create({
        "id": "context_tab_queue",
        "title": "Send current tab to queue",
        "contexts": ["all"],
        "onclick": onContextMenuLinkClicked
    });
}
/********************************************
 * EVENTS
 */
/**
 * Context Menu action
 */
function onContextMenuLinkClicked(info, tab) {
    // Open new tab with url, queue override
    if (info.menuItemId === "context_no_queue") {
        openUrlInTab(tab.windowId, info.linkUrl, tab.index + 1, true, false);
    }
    // Save url directly to queue
    else if (info.menuItemId === "context_queue") {
        clog("Saving Item");
        var item = new Item(DEFAULT_ID, tab.windowId, info.linkUrl, tab.title, "complete", false);
        saveItem(item);
    } else if (info.menuItemId === "context_tab_queue") {
        queueTab(tab);
    }
}

/**
 * Simply save the new tab id and check later when url gets updated
 * this fixes the problem with blank url when opening a link with target="_blank"
 */
function onCreatedTab(newTab) {
    if (!isActive) {
        return;
    }
    // If the tab is overriding the limit, don't
    // push it into the waiting list
    if (!isOverriding) {
        tabsWaiting.push(newTab);
    }
    isOverriding = false; // Reset override for the next one
}
/**
 * New tab created, check limit and add to queue
 */
function onUpdatedTab(tabId, tabInfo, tabState) {
    //First check if the updated tab is one of the new ones
    if (!isActive || tabInfo.pinned || !findTabWaiting(tabId, true)) {
        return;
    }
    // Get tabs in updated tab window
    chrome.tabs.query({
        windowId: tabState.windowId
    }, function(windowTabs) {
        if (chrome.runtime.lastError !== undefined) {
            cerror("An error ocurred onUpdatedTab: " + chrome.runtime.lastError.string);
        }

        // Get number of opened tabs, whitelisted and pinned excluded
        var freeSpace = calculateFreespace(windowTabs);
        // If no limit exceeded, do nothing
        // else add to urlQueue
        if (freeSpace >= 0) {
            return;
        } else {
            // Queue new tab url and close it
            queueTab(tabState);
        }
    });
}
/**
 * Check related queue and reset its id
 */
function onWindowRemoved(id) {
    var queue = getQueue(id);
    if (queue.items.length > 0) {
        queue.name = formatDateTime(Date.now());
        queue.window = DEFAULT_ID;
        /*for (var i = 0; i < queue.items.length; i++) {
              queue.items[i].window = DEFAULT_ID;
          }*/
    }
}

/**
 * MIGRATE. On installed or updated, import queue from old versions (<= 1.0)
 */
function onInstalled() {
    function queueDataRetrieved(items) {
        // Fill queue
        if (items.hasOwnProperty('queueLength')) {
            // Get/create a new queue
            var q = getQueue(DEFAULT_ID);
            // Keys to remove when finished
            var keys = ['queueLength'];
            for (var i = 0; i < items.queueLength; i++) {
                // Create item
                var k = 'item' + i;
                var item = new Item(DEFAULT_ID, DEFAULT_ID, items[k], "", "complete", false);
                keys.push(k); // Push to remove when finished
                // push to queue
                q.items.push(item);
            }
            // Cleanup old items in storage and save new queue
            chrome.storage.local.remove(keys, function() {
                if (chrome.runtime.lastError !== undefined) {
                    cerror("An error ocurred removing old storage keys: " + chrome.runtime.lastError.string);
                    return;
                }
            });
            cleanAndStore();
        }
    }
    chrome.storage.local.get(null, queueDataRetrieved);
}

/********************************************
 * Register listeners
 */
document.addEventListener("DOMContentLoaded", init);
chrome.storage.onChanged.addListener(onSettingsChanged);
chrome.tabs.onCreated.addListener(onCreatedTab);
chrome.tabs.onUpdated.addListener(onUpdatedTab);
chrome.windows.onRemoved.addListener(onWindowRemoved);
chrome.runtime.onInstalled.addListener(onInstalled);