# Version log
Short changelog for the main public version. The dates correspond with the dates of release in Chrome Store.
Full changelog here: https://raw.githubusercontent.com/rubenmv/chrome-extension-tabs-queue/master/release/CHANGELOG.md

### [2.0.4] 2017-12-05
- Added context menu entries for sending links and tabs directly to the queue.
- Added whitelist exceptions for "The Great Suspender" suspended tabs.
- Fixes some problems with internal tab count.
